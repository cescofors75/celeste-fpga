# CELESTE · Parallel Fabric

Prototipo incremental para Tang Nano 20K + PCM5102, con interfaz inspirada en
las dos referencias visuales. **Streaming limpio cargado en SRAM y probado
con la placa: 48 kHz estéreo, cero errores en pruebas de 5, 20 y 15 segundos.
El usuario confirmó escucha correcta de un WAV desde el navegador por el
PCM5102. Ahora están cargados Glitch, Delay y Filter paralelos, control web,
rotarys físicos, HDMI y ST7789.** Detalles y límites: [DSP V1](docs/DSP_V1.md).

## Implementado y probado

- Interfaz PATCH / PERFORM / PRESETS / HARDWARE / SETTINGS, grafo editable,
  parámetros, asignaciones por patch, eventos táctiles configurables.
- WAV → worker Rust/WASM → PCM16 estéreo 48 kHz, remuestreo de 44.1 kHz,
  forma de onda, Play/Stop/Loop mediante monitor local seco.
- Patches y sesiones JSON versionados, validación Rust, persistencia local,
  referencia SHA-256 a la muestra original sin incrustarla en JSON.
- Adaptador candidato Web Serial con handshake, secuencias, CRC, estados
  reales y control de flujo por ocupación FIFO. Sin telemetría simulada.
- RTL portable: receptor/endpoint de protocolo, FIFO síncrono, salida I²S
  heredada, prefill, drain de EOF, silencio y contador de underrun.
- Prueba RTL de extremo a extremo: paquetes generados por Rust → receptor →
  FIFO → bits I²S de ambos canales. Esto es simulación, no prueba del DAC.

## Ejecutar

Requisitos: Node 22.12+ (verificado con 24), Rust, target
`wasm32-unknown-unknown`, wasm-bindgen CLI **0.2.100**. En Windows este equipo
usa Rust GNU y MinGW porque no dispone del enlazador MSVC. El build WASM de
desarrollo se ha verificado; algunos ejecutables del build release fueron
bloqueados por Smart App Control. No se modificó esa protección.

```powershell
npm ci
npm run wasm
npm run dev -- --port 5173
```

Abrir [CELESTE local](http://127.0.0.1:5173). `Load WAV`, seleccionar archivo,
mantener `Local dry monitor` y pulsar Play. Los efectos editados en el patch
no se aplican al monitor local. `FPGA → PCM5102` permanece bloqueado sin un
handshake real del protocolo compatible.

El script Windows busca wasm-bindgen en PATH o en
`build/tools/wasm-bindgen-0.2.100-x86_64-pc-windows-msvc/wasm-bindgen.exe`.
Se puede instalar con `cargo install wasm-bindgen-cli --version 0.2.100 --locked`
en un entorno de compilación compatible, o usar el binario oficial de
[la release 0.2.100](https://github.com/rustwasm/wasm-bindgen/releases/tag/0.2.100).
Los archivos generados de WASM, dependencias y builds no se incluyen en Git.
El script elige Rust GNU si detecta `C:/msys64/mingw64/bin/gcc.exe`; instalar
ese toolchain y su target WASM con rustup en máquinas equivalentes.

En Linux/macOS, compilar con `cargo build --manifest-path rust/Cargo.toml
-p celeste-wasm --target wasm32-unknown-unknown` y ejecutar wasm-bindgen sobre
`rust/target/wasm32-unknown-unknown/debug/celeste_wasm.wasm` con
`--target web --out-dir web/src/wasm --out-name celeste_wasm`.

## Verificar

```powershell
npm run test:rust
npm test
npm run test:rtl
npm run build
# Con el servidor en 5173 y Chromium de Playwright instalado:
npm run test:browser
```

Icarus Verilog: PATH o `C:/msys64/ucrt64/bin`. Para instalar el navegador de
pruebas: `npx playwright install chromium`. El WAV de prueba se genera en
`build/`, sin depender de archivos de audio externos. Los vectores RTL están
versionados; su generador es `rust/celeste-core/examples/vectors.rs`.

## Siguiente hito obligatorio

1. Prueba de escucha de DSP, rotarys físicos y aspecto de HDMI/ST7789.
2. Ampliar las pruebas a loop/reconexión y muestras largas. Tres pruebas de
   30 segundos con cambios de filtro y lectura de vuelta terminaron sin errores.
   STOP/restart/EOF ya habían pasado diez ciclos reales.

## Prueba en la placa

La placa está preparada mientras conserve alimentación. En Chrome o Edge,
abrir http://127.0.0.1:5173, `CONNECT DEVICE`, elegir **COM14 / interfaz B**,
`Load WAV`, salida **FPGA → PCM5102**, Play. SETTINGS muestra los contadores
reales. El modo Local dry monitor reproduce por el ordenador.

En PERFORM puedes variar Glitch, Delay, Filter y las cuatro mezclas. Los rotarys
de la web aceptan arrastre vertical y flechas; doble clic abre asignaciones.
Los valores físicos se leen de la FPGA. El delay máximo es **170,7 ms**;
Wavefolder, VCA, LFO y Chaos están activos; el botón táctil controla bypass.
LFO y Chaos modulan Filter y VCA. Las ramas de audio son instancias fijas
en paralelo: dibujar otro bloque no crea otro motor físico.

Después de desconectar la placa, cerrar la conexión del navegador y ejecutar:

```powershell
python scripts/prepare_board.py
```

Necesita Python con pyserial (`python -m pip install pyserial`) y el build
Gowin en `build/stream/impl/pnr/celeste_stream.fs`. Configura CLK2 a 12.288 MHz
de forma volátil y carga solo SRAM; no graba Flash ni guarda el reloj.
El script comprueba cierre de timing y handshake. Para repetir el tono:

```powershell
python scripts/hardware_stream.py --seconds 20 --tone
```

Cerrar primero Web Serial para liberar COM14. El tono es de baja amplitud,
440 Hz izquierda / 660 Hz derecha. Ver `docs/HARDWARE_TRANSPORT_PROOF.md`.

Documentación: [arquitectura](docs/ARCHITECTURE.md),
[protocolo y evidencia USB](docs/PROTOCOL.md), [formatos](docs/PATCH_FORMAT.md),
[recursos](docs/FPGA_RESOURCES.md), [validación](docs/VALIDATION.md).

Auditoría sonora del 20/09/2026: [resultados, correcciones y límites del
paralelismo](docs/AUDIO_AUDIT.md). Ejecutar `npm run test:audio` para la batería
numérica de DSP y `npm run test:all -- --browser` para reunir las comprobaciones
(servidor web activo; Python con NumPy e Icarus necesarios para audio).

Ampliación posterior: [bypass por componente y dos delays en serie/paralelo](docs/DUAL_DELAY.md).
Delay 1 conserva 170,7 ms y Delay 2 añade 85,3 ms. Requiere firmware con
capacidad 0x100; el bypass se guarda en el patch y deja pasar la entrada.

Actualización: pruebas UART temporales en SRAM confirman 304.993 bytes/s hacia
el FPGA durante 2 MiB, con recuento/suma correctos y cero errores de trama.
Se restauró la imagen SRAM anterior; Flash y el proyecto anterior permanecen
intactos. Esto aún no valida audio con protocolo. Ver
[prueba física](docs/HARDWARE_TRANSPORT_PROOF.md).
