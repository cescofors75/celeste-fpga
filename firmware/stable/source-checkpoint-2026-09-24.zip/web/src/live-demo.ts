import {defaultPatch,type Patch} from './model';
export const liveScenes=['Señal limpia','Filter + Wavefolder · paralelo','Dos delays · paralelo','Delay → Delay 2 · serie','LFO + Chaos · movimiento','Glitch · fragmentos'];
export const LIVE_SECONDS=48;
export function liveDemoFrame(seconds:number):{patch:Patch;scene:number;label:string}{
 const time=((seconds%LIVE_SECONDS)+LIVE_SECONDS)%LIVE_SECONDS,scene=Math.floor(time/8),local=time%8;
 // Return wet branches to zero before changing topology; a quiet dry bed
 // bridges scene boundaries. Hardware gain slews add a second smoothing layer.
 const wet=Math.min(1,local,8-local),p=defaultPatch();
 p.name='CELESTE · Demo live';p.bypass={};
 p.nodes={sample:[24,250],glitch:[465,12],delay:[465,122],delay2:[635,122],filter:[465,232],wavefolder:[465,342],vca:[465,452],mixer:[807,245],out:[957,245],lfo:[210,32],chaos:[210,390]};
 p.modulation=[];p.routes=[['sample','mixer'],['mixer','out']];
 Object.assign(p.parameters,{'mixer.dry':.35,'mixer.glitch':0,'mixer.delay':0,'mixer.delay2':0,'mixer.filter':0,'mixer.wavefolder':0,'mixer.vca':0,'mixer.master':.65,'lfo.depth':0,'chaos.amount':0,'filter.cutoff':.12,'filter.resonance':.4,'filter.mode':0,'wavefolder.drive':.55,'delay.time':.82,'delay.feedback':.5,'delay2.time':.75,'delay2.feedback':.6,'vca.level':1,'lfo.rate':.16,'chaos.rate':.22,'glitch.amount':1,'glitch.probability':.65,'glitch.mode':1,'glitch.size':1,'glitch.repeats':.2});
 const branch=(id:string,gain:number)=>{p.routes.push(['sample',id],[id,'mixer']);p.parameters['mixer.'+id]=gain*wet;};
 if(scene===0)p.parameters['mixer.dry']=.35+.25*wet;
 if(scene===1){branch('filter',.3);branch('wavefolder',.08);p.parameters['wavefolder.drive']=.15;p.parameters['filter.cutoff']=.04+.4*(.5-.5*Math.cos(local*Math.PI/4));}
 if(scene===2){branch('delay',.24);branch('delay2',.24);}
 if(scene===3){p.routes.push(['sample','delay'],['delay','delay2'],['delay2','mixer']);p.parameters['mixer.delay2']=.4*wet;}
 if(scene===4){branch('vca',.5);branch('filter',.25);p.parameters['mixer.dry']=.35*(1-wet);p.parameters['lfo.depth']=1;p.parameters['chaos.amount']=.8;p.modulation=[['lfo','vca.level'],['chaos','filter.cutoff']];}
 // Short hardware grains can buzz when repeated fully wet over a sustained pad.
 // Keep the ambient bed and introduce occasional, quieter fragments.
 if(scene===5){branch('glitch',.18);p.parameters['mixer.dry']=.35-.05*wet;p.parameters['glitch.amount']=.5;p.parameters['glitch.probability']=.3;p.parameters['glitch.repeats']=.0625;}
 return {patch:p,scene,label:liveScenes[scene]};
}
// Sample-counter time follows real hardware consumption, not tab timer cadence.
export class LiveDemoClock{
 private last=0;seconds=0;paused=false;
 start(counter:number){this.last=counter;this.seconds=0;this.paused=false;}
 advance(counter:number){const delta=(counter-this.last)>>>0;this.last=counter;if(!this.paused)this.seconds+=delta/48000;return this.seconds;}
}
