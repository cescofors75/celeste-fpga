/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_preparedaudio_free: (a: number, b: number) => void;
export const encode_packet: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const preparedaudio_chunk: (a: number, b: number, c: number) => [number, number];
export const preparedaudio_metadata: (a: number) => [number, number];
export const preparedaudio_new: (a: number, b: number) => [number, number, number];
export const preparedaudio_waveform: (a: number, b: number) => [number, number];
export const validate_packet: (a: number, b: number) => [number, number];
export const validate_patch: (a: number, b: number) => [number, number, number, number];
export const validate_session: (a: number, b: number) => [number, number, number, number];
export const __wbindgen_export_0: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
