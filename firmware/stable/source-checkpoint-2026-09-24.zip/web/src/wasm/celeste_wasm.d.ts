/* tslint:disable */
/* eslint-disable */
export function validate_patch(s: string): string;
export function validate_session(s: string): string;
export function encode_packet(kind: number, sequence: number, payload: Uint8Array): Uint8Array;
export function validate_packet(bytes: Uint8Array): void;
export class PreparedAudio {
  free(): void;
  constructor(bytes: Uint8Array);
  chunk(start: number, count: number): Uint8Array;
  metadata(): string;
  waveform(bins: number): Float32Array;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_preparedaudio_free: (a: number, b: number) => void;
  readonly encode_packet: (a: number, b: number, c: number, d: number) => [number, number, number, number];
  readonly preparedaudio_chunk: (a: number, b: number, c: number) => [number, number];
  readonly preparedaudio_metadata: (a: number) => [number, number];
  readonly preparedaudio_new: (a: number, b: number) => [number, number, number];
  readonly preparedaudio_waveform: (a: number, b: number) => [number, number];
  readonly validate_packet: (a: number, b: number) => [number, number];
  readonly validate_patch: (a: number, b: number) => [number, number, number, number];
  readonly validate_session: (a: number, b: number) => [number, number, number, number];
  readonly __wbindgen_export_0: WebAssembly.Table;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
