import {describe,it,expect} from 'vitest';
import {liveDemoFrame,LiveDemoClock} from './live-demo';
import {ControlLink,delay2Config} from './control';
describe('live FPGA demo score',()=>{
 it('compiles every transition to supported controls and keeps conservative mixer gain',()=>{
  const c=new ControlLink();c.extended=c.dual=c.sonic=c.banked=true;
  for(let t=0;t<96;t+=.25){const {patch:p}=liveDemoFrame(t);expect(()=>c.queue(p)).not.toThrow();
   const gains=Object.entries(p.parameters).filter(([k])=>k.startsWith('mixer.')&&k!=='mixer.master').reduce((sum,[,v])=>sum+v,0);
   expect(gains*p.parameters['mixer.master']).toBeLessThanOrEqual(.6);
  }
 });
 it('uses genuinely different parallel/series and modulation routes',()=>{
  expect(delay2Config(liveDemoFrame(20).patch)).toBe(1);
  expect(delay2Config(liveDemoFrame(28).patch)).toBe(3);
  expect(liveDemoFrame(36).patch.modulation).toEqual([['lfo','vca.level'],['chaos','filter.cutoff']]);
  const glitch=liveDemoFrame(44).patch.parameters;
  expect(glitch['mixer.glitch']).toBeGreaterThan(0);
  expect(glitch['mixer.dry']).toBeGreaterThan(glitch['mixer.glitch']);
 });
 it('silences wet contributions at topology boundaries and repeats exactly',()=>{
  for(let t=0;t<48;t+=8){const p=liveDemoFrame(t).patch;for(const b of ['delay','delay2','filter','wavefolder','glitch','vca'])expect(p.parameters['mixer.'+b]).toBe(0);}
  expect(liveDemoFrame(48)).toEqual(liveDemoFrame(0));
 });
 it('pauses score time while consumption continues and handles counter wrap',()=>{
  const c=new LiveDemoClock();c.start(0xffff0000);c.advance((0xffff0000+48000)>>>0);expect(c.seconds).toBe(1);
  c.paused=true;c.advance((0xffff0000+96000)>>>0);expect(c.seconds).toBe(1);
  c.paused=false;c.advance((0xffff0000+144000)>>>0);expect(c.seconds).toBe(2);
 });
});
